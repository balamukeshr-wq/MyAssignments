import { test } from "playwright/test"
import { BasePage } from "../pages/Base_page/Base_page" //Base page as center, contains Page
import dotenv from "dotenv";//inmporting dotenv
import { loginPage } from "../pages/Login_page/login_page";//importing login page method
import { Leads_page } from "../pages/Leads_page/Leads_basepage";
import { CreateLeadsPage } from "../pages/Leads_page/Create_leadspage";


const filename = process.env.filename;//storing env_value as filename
dotenv.config({ path: `Data/${filename}.env` });//accesing env thorugh filename
//$env:filename="qa" is to assign the value to the filename
const BaseUrl:string = process.env.BaseUrl as string;
const Username:string =process.env.LF_Username as string;
const Password:string =process.env.LF_Password as string;

test("POM_Assignment_Day_11", async ({ page }) => {

    //object for BasePage
    const objBase = new BasePage(page)
    await objBase.LoadUrl(BaseUrl);

    //object for LoginPage
    const objLogin =new loginPage(page)
    await objLogin.Loginmethod(Username,Password);
    await objLogin.clickLogin();
    await objLogin.Welcomebutton();

    //object for leadspage
    const objLeads= new Leads_page(page)
    await objLeads.clickLeads();
    await objLeads.createLeads();

    //obje for createleadspage
    const objcreateLeads =new CreateLeadsPage(page)
    await objcreateLeads.fillLeaddetails("ABCD","Bala","Mukesh");
    await objcreateLeads.Dropdownvalues();

})