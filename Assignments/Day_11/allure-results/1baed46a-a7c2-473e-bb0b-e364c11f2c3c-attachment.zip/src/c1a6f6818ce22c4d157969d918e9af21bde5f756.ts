import { Accounts_page } from "./Account_basepage";

export class CreateAccountsPage extends Accounts_page {
    async fillAccountdetails(){
        await this.page.getByRole("textbox",{name:`accountName`}).fill('Bala');
        await this.page.getByRole("combobox",{name:`Industry`}).selectOption({value:"IND_SOTWARE"})
        
        const indusdropdown= await this.page.getByRole("combobox",{name:`Industry`}).allInnerTexts();
        for (const optionText of indusdropdown){
            console.log('Industry Option',optionText)
        }

    }
}