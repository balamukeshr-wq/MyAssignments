import { test } from "playwright/test"
import { BasePage } from "../pages/Base_page"
import dotenv from "dotenv";
import { loginPage } from "../pages/Login_page/login_page";


const filename = process.env.filename;
dotenv.config({ path: `Data/${filename}.env` });
//$env:filename="qa" is to assign the value to the filename
const BaseUrl:string = process.env.BaseUrl as string;
const Username:string =process.env.LF_Username as string;
const Password:string =process.env.LF_Password as string;

test("POM_Assignment_Day_11", async ({ page }) => {

    //object for BasePage
    const objBase = new BasePage(page)
    await objBase.LoadUrl(BaseUrl);

    //object for LoginPage
    const objLogin =new loginPage(page)
    await objLogin.Loginmethod(Username,Password);
    await objLogin.clickLogin();
    await objLogin.Welcomebutton();

})