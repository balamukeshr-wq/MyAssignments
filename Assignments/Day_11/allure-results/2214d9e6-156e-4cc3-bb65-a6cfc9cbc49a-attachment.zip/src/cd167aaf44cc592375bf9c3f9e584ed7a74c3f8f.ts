import { BasePage } from "../base_page/Base_page";

export class Accounts_page extends BasePage{

    async clickAccounts(){
        await this.page.locator(`//a[text()="Accounts"]`).click();
    }

    async createAccount(){
        await this.page.locator(`//a[text()="Create Account"]`).click();
    }
}