import { Accounts_page } from "./Account_basepage";

export class CreateAccountsPage extends Accounts_page {
    async fillAccountdetails(){
        await this.page.locator(`//input[@id="accountName"]`).fill('Bala');

        await this.page.locator(`//select[@name="industryEnumId"]`).selectOption({value:"IND_SOTWARE"})
        
        const indusdropdown= await this.page.locator(`//select[@name="industryEnumId"]/option`).allInnerTexts();
        for (const optionText of indusdropdown){
            console.log('Industry Option',optionText)
        }

    }
}