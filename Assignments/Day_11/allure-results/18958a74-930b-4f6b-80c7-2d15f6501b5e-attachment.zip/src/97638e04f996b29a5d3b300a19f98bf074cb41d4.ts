import { UtiltyWrapper } from "../../utilities/utility";

export class CreateLeadsPage extends UtiltyWrapper {

    async fillLeaddetails(companyName: string, firstName: string, lastName: string) {
        await this.fillandtab('//input[@id="createLeadForm_companyName"]', companyName);
        await this.fillandtab(`//input[@id="createLeadForm_firstName"]`, firstName);
        await this.fillandtab(`//input[@id="createLeadForm_lastName"]`, lastName);
    }
    

    async Dropdownvalues() {

        //await this.page.locator(`//select[@id="createLeadForm_dataSourceId"]`).click();
        await this.page.locator(`//select[@id="createLeadForm_dataSourceId"]`).selectOption("LEAD_DIRECTMAIL");

        //await this.page.locator(`//select[@id="createLeadForm_marketingCampaignId"]`).click();
        await this.page.locator(`//select[@id="createLeadForm_marketingCampaignId"]/option[text()="Demo Marketing Campaign"]`).click();

        const dropdowncount = await this.page.locator(`//select[@id="createLeadForm_marketingCampaignId"]/option`).count();

        for (let i = 0; i < dropdowncount; i++) {
            let dropDownValues = await this.page.locator('//select[@id="createLeadForm_dataSourceId"]/option').nth(i).innerText();
            console.log(dropDownValues);

        }

        await this.page.locator(`//select[@id="createLeadForm_industryEnumId"]/option[text()="General Services"]`).click();

        await this.page.locator(`//select[@id="createLeadForm_currencyUomId"]`).click();
        await this.page.locator(`//select[@id="createLeadForm_currencyUomId"]/option[@value="INR"]`).click();

        await this.page.locator(`//select[@id="createLeadForm_generalCountryGeoId"]`).click();
        await this.page.locator(`//select[@id="createLeadForm_generalCountryGeoId"]/option[@value="IND"]`).click();

        const statecount = await this.page.locator(`//select[@id="createLeadForm_generalStateProvinceGeoId"]/option`).count();

        await this.page.locator(`//select[@id="createLeadForm_generalStateProvinceGeoId"]`).click();
        await this.page.locator(`//select[@id="createLeadForm_generalStateProvinceGeoId"]/option[text()="TAMILNADU"]`).click();

        for (let i = 0; i < statecount; i++) {
            let dropDownValues = await this.page.locator(`//select[@id="createLeadForm_generalStateProvinceGeoId"]`).nth(i).innerText();
            console.log(dropDownValues);

        }
    }
}